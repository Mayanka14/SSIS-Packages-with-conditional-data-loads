--Part 6: Show the sql to find all the titles with more than one author.
USE pubs;
SELECT t.title_id AS 'ID',t.title AS 'Title',COUNT(ta.au_id) AS 'Total Number of Authors'
FROM [dbo].[titles] AS t
JOIN [dbo].[titleauthor] AS ta
ON t.title_id=ta.title_id
GROUP BY t.title_id,t.title
HAVING COUNT(t.title_id)>1
ORDER BY t.title_id;



-- Part 7: Show the sql to show all the authors with more than one book

USE pubs;
SELECT a.au_id,CONCAT(au_fname,' ',au_lname) AS 'Author`s Name',COUNT(ta.title_id) AS 'Total Number of Books'
FROM [dbo].[authors] AS a
JOIN [dbo].[titleauthor] AS ta
ON a.au_id=ta.au_id
GROUP BY a.au_id,a.au_fname,a.au_lname
HAVING COUNT(ta.title_id)>1
ORDER BY [Author`s Name];


-- If we wish to retreive the names of the books written by these authors, we can use the following query
SELECT CONCAT(au_fname,' ',au_lname) AS 'Author`s Name',t.title AS 'Book'
FROM [dbo].[authors] AS a
JOIN [dbo].[titleauthor] AS ta
ON a.au_id=ta.au_id
JOIN [dbo].[titles] AS t
ON ta.title_id=t.title_id
WHERE a.au_id IN(SELECT a.au_id FROM [dbo].[authors] AS a
                 JOIN [dbo].[titleauthor] AS ta
                 ON a.au_id=ta.au_id
				GROUP BY a.au_id
				HAVING COUNT(ta.title_id)>1)
ORDER BY [Author`s Name];




--Part 8: Show the sql to show the publishers with no titles

SELECT p.pub_id AS 'Publisher`s ID',p.pub_name AS 'Publisher`s Name'
FROM [dbo].[publishers] AS p
LEFT JOIN [dbo].[titles] AS t
ON p.pub_id=t.pub_id
WHERE t.title_id IS NULL
ORDER BY [Publisher`s ID];

